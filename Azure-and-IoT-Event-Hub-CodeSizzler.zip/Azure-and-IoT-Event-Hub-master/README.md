# Azure-and-IoT-Event-Hub
The following repository consists of all the slides and documentation of the Microsoft Azure and IoT Event Hub
